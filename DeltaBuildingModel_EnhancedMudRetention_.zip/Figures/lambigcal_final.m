%% 각 timestep 에서 전체 면적의 S/M 비율 : 최종 run 이후에 실행

Atotal= (70*pi/180) * 0.5 * shoreline.^2;
Amud=(35*pi/180) * (shoreline-thres).^2 ; % mud
Asand=Atotal-Amud;
ms_ratio=Amud./Asand;
ms_ratio(shoreline<thres)=0;
hold off
figure,plot(timeplot+100,ms_ratio+1) % 하나의 레이어가 쌓일 동안의 m/s raio이 니까 x축에 time이 오는게 맞다.
ylabel('lambda')
xlabel('time yr')