% error=[150, 150, 110, 50, 80, 50, 70, 50, 60, 60]; ## 추세선으로 다시
year=[110, 140, 130, 540, 350, 500, 680, 660, 680, 860];
distance=[9000, 20000, 26000, 48000, 51000, 51000, 72000, 75000, 77000, 110000];
ttt=[0:800];
yy=109.5*ttt+2982;
plot(ttt,yy,'r')
hold on
plot(year,distance,'r+')


Bc=1000:500:10000;
Frac=0:50:600;

diff_squared_sum=zeros(length(Bc),length(Frac)); 

load('[new]_Bc_50000_FracDeposit_0.mat')
shoreline_red=shoreline; % red means base model here
lm=fitlm(timeplot+100,shoreline_red);
min_rsq=cell2mat(struct2cell(lm.Rsquared(1)));
max_MSE=lm.MSE;

for  Bc = 1000 : 500 : 10000  
    for Frac=0:50:600 
        
        iii=(Bc)/500-1;
        jjj=(Frac/50)+1;
        
            load(['[new]_Bc_' num2str(Bc) '_FracDeposit_' num2str(Frac) '.mat'])   
            timeplot=timeplot+100;            
             lm = fitlm(timeplot,shoreline);
             temp=struct2cell(lm.Rsquared);
             rsq(iii,jjj)=cell2mat(temp(1));
             MSE(iii,jjj)=lm.MSE;
%             diff=shoreline-shoreline_red;
            diff=shoreline-yy';
            diff_squared_sum(iii,jjj)=sum(diff.^2);
    end
end

% load('diff_squared_sum')
diff_squared_sum(diff_squared_sum==0)=NaN;
% ans=max(diff_squared_sum);
% maximum=max(ans,[],'all');

diff_red = (shoreline_red-yy');
diff_squared_sum_red = sum(diff_red.^2);

% diff_squared_sum_normalized= diff_squared_sum / maximum;
diff_squared_sum_normalized= diff_squared_sum / diff_squared_sum_red;

% diff squared sum을 red line의 diff squared sum으로 normalized 한 것. red line
% 보다 최대 82%로 오차를 감소시킬 수 있다는 의미
figure
pcolor(diff_squared_sum_normalized)
shading interp
% colormap('jet')
colorbar;
hold on
contour(diff_squared_sum_normalized,5,'k')
title('MSE from field regression, normalized by MSE of previous model')

min_rsq(1)=1  % 이건 rsquare에 min 으로 나누는게 의미가 없어
% r squred
figure
pcolor(rsq./min_rsq(1))
shading interp
% colormap('jet')
colorbar;
hold on
contour(rsq./min_rsq(1),5,'k')
title('R squared value of lm')

% MSE
figure
pcolor(MSE./max_MSE)
shading interp
% colormap('jet')
colorbar;
hold on
contour(MSE./max_MSE,5,'k')
title('MSE 평균제곱오차 of lm')




%%
sta=MSE./max_MSE;
mean_sta=mean(sta,'all')
median_sta=median(sta,'all')
std_sta=std(sta(:))


Bc=1000:500:10000;
Bc=Bc';
Bc_sta=sta(:);
Bc_sta2= [Bc;Bc;Bc;Bc;Bc;Bc;Bc;Bc;Bc;Bc;Bc;Bc;Bc];
[rhobc,pvalbc]=corr(Bc_sta,Bc_sta2)


qmi = 0 : 0.5 : 6;
qmi=qmi';
qmi=qmi*10E-08;
qmi_sta2=[qmi;qmi;qmi;qmi;qmi;qmi;qmi;qmi;qmi;qmi;qmi;qmi;qmi;qmi;qmi;qmi;qmi;qmi;qmi;];

qmi_sta=sta(1,:)';
for i = 2 : 19
    qmi_sta =[ qmi_sta; sta(i,:)' ];
end

[rhoqm,pvalqm]=corr(qmi_sta,qmi_sta2)

%%
qmi_sta2=[qmi;qmi;qmi;qmi;qmi;qmi;qmi];
qmi_sta=sta(1,:)';
for i = 2 : 7
    qmi_sta =[ qmi_sta; sta(i,:)' ];
end
[rhoqm,pvalqm]=corr(qmi_sta,qmi_sta2)


qmi_sta=sta(13,:)';
for i = 14 : 19
    qmi_sta =[ qmi_sta; sta(i,:)' ];
end
[rhoqm,pvalqm]=corr(qmi_sta,qmi_sta2)

