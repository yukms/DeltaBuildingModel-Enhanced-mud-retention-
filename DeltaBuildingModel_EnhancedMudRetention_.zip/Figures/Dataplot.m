error=[150, 150, 110, 50, 80, 50, 70, 50, 60, 60];
year=[110, 140, 130, 540, 350, 500, 680, 660, 680, 860];
distance=[9000, 20000, 26000, 48000, 51000, 51000, 72000, 75000, 77000, 110000];

figure
hold on

    errorbar( year,distance,error,'horizontal' ,'k+','linewidth',1);
xlabel('year')
ylabel('distance [m]')



ttt=[1:1000];
yy=109.5*ttt+2982;
plot(ttt,yy,'r')
plot(timeplot+100,shoreline)

