%% Mud retention increase plot
% Data Gathering bottomset
% 
Bc=1000:500:10000;
Frac=0:50:600;
Data.shoreline=zeros(801,length(Frac));
tempi=0;
for  FracDeposit = 0 : 50: 600
    tempi=tempi+1;
            load(['[new]_Bc_' num2str(10000) '_FracDeposit_' num2str(FracDeposit) '.mat'])   
    Data.shoreline(:,tempi)=shoreline(1:801);
end
timeplot=timeplot+100;
for i = 1:length(Frac)
    timeplot(:,i)=timeplot(:,1);
end

FracDeposit=zeros(801,length(Frac));
FracDeposit_1=0:50:600;
for i = 1 : 801
    FracDeposit(i,:)=FracDeposit_1;
end



error=[150, 150, 110, 50, 80, 50, 70, 50, 60, 60];
year=[110, 140, 130, 540, 350, 500, 680, 660, 680, 860];
distance=[9000, 20000, 26000, 48000, 51000, 51000, 72000, 75000, 77000, 110000];

figure('Position', [100 100 800 600],'Renderer','Painters')

pcolor(timeplot,Data.shoreline,FracDeposit);
shading interp
ylabel('distance from apex [m]','FontSize',16);
xlabel('year','FontSize',16);
colorbar
hcb=colorbar;
hcb.Title.String = "qmo e-06";
hold on
errorbar( year,distance,error,'horizontal' ,'k+');
xlim([-100 1000])
ylim([0 12E4])


load('[new]_Bc_50000_FracDeposit_0.mat')
hold on
plot(timeplot+100,shoreline,'r')



