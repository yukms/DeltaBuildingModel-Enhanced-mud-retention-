%% Mud retention increase plot
% Data Gathering bottomset
Bc=1000:500:10000;
Data.shoreline=zeros(801,length(Bc));
tempi=0;
for  Bc = 1000 : 500: 10000
    tempi=tempi+1;
   if exist(['[new]_Bc_' num2str(Bc) '_FracDeposit_' num2str(0) '.mat'])==2
            load(['[new]_Bc_' num2str(Bc) '_FracDeposit_' num2str(0) '.mat'])   
   else
   end
   
    Data.shoreline(:,tempi)=shoreline(1:801);
end
timeplot=timeplot+100;
for i = 1: size(Data.shoreline,2)
    timeplot(:,i)=timeplot(:,1);
end
Bc= 1000 : 500 : 10000;
Bc=Bc';
for i = 1 : 801
    Bc(:,i)=Bc(:,1);
end


error=[150, 150, 110, 50, 80, 50, 70, 50, 60, 60];
year=[110, 140, 130, 540, 350, 500, 680, 660, 680, 860];
distance=[9000, 20000, 26000, 48000, 51000, 51000, 72000, 75000, 77000, 110000];

figure('Position', [100 100 800 600],'Renderer','Painters')

pcolor(timeplot,Data.shoreline,Bc');
shading interp
ylabel('distance [m]','FontSize',16);
xlabel('year','FontSize',16);
colorbar
hcb=colorbar;
hcb.Title.String = "B_(channel)";
hold on
errorbar( year,distance,error,'horizontal' ,'k+');
xlim([-100 1000])
ylim([0 12E4])


load('[new]_Bc_50000_FracDeposit_0.mat')
hold on
plot(timeplot+100,shoreline,'r')