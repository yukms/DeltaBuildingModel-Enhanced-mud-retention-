error=[150, 150, 110, 50, 80, 50, 70, 50, 60, 60];
year=[110, 140, 130, 540, 350, 500, 680, 660, 680, 860]';
distance=[9000, 20000, 26000, 48000, 51000, 51000, 72000, 75000, 77000, 110000]';
distance_df=[9000, 20000, 26000, 48000, 51000, 51000, 72000, 75000, 77000]';
deltafront=[1.2, 2, 1.6, 1.3, 0.8, 1.7, 1.1, 1.5, 1.4]';
deltafront_error=[ 0.4, 0.4, 0.5, 0.4, 0.1, 0.5, 0.3, 0.4, 0.4]';
mouthbar = [1.7, 2.9, 2.2, 2.1, 2.7, 0.8, 2.4, 2, 1.8, 3.8]' ;
mouthbar_error = [0.5, 1.3, 0.5, 0.3, 0.2, 0.4, 0.8, 0.1, 0.4, 0.2]';

%% fbb plot
fig1=figure
set(fig1,'Position',[0,100,800,500])
errorbar ( distance_df, deltafront, deltafront_error,'vertical','o','MarkerSize',7,'color',[0.4 0.7 0.4],'linewidth',3)
hold on
%% mouth bar plot
errorbar ( distance, mouthbar, mouthbar_error,'vertical','o','MarkerSize',7,'color',[1 0.5 0],'linewidth',1)

%% simulation result plot

% (c) '-o'
load('[new]_Bc_1000_FracDeposit_0.mat')
plot(fbb,etafbb+4,'color',[0.4 0.7 0.4])
hold on
plot( (fbb+shoreline)/2 ,etashoreline-etafbb,'color',[1 0.5 0])
plot(fbb(1:40:801),etafbb(1:40:801)+4,'square','color',[0.4 0.7 0.4])
plot( (fbb(1:40:801)+shoreline(1:40:801))/2 ,etashoreline(1:40:801)-etafbb(1:40:801),'square','color',[1 0.5 0])


% (d) '-square'
load('[new]_Bc_10000_FracDeposit_400.mat')
plot(fbb,etafbb+4,'color',[0.4 0.7 0.4])
hold on
plot( (fbb+shoreline)/2 ,etashoreline-etafbb,'color',[1 0.5 0])
plot(fbb(1:40:801),etafbb(1:40:801)+4,'diamond','color',[0.4 0.7 0.4])
plot( (fbb(1:40:801)+shoreline(1:40:801))/2 ,etashoreline(1:40:801)-etafbb(1:40:801),'diamond','color',[1 0.5 0])
% (f)  
load('[new]_Bc_1000_FracDeposit_400.mat')
plot(fbb,etafbb+4,'color',[0.4 0.7 0.4],'linewidth',2)
hold on
plot( (fbb+shoreline)/2 ,etashoreline-etafbb,'color',[1 0.5 0],'linewidth',2)
% plot(fbb(1:40:801),etafbb(1:40:801)+4,'color',[0.4 0.7 0.4])
% plot( (fbb(1:40:801)+shoreline(1:40:801))/2 ,etashoreline(1:40:801)-etafbb(1:40:801),'color',[1 0.5 0])



% %% trendline of field data
% f= fit(distance_df, deltafront,'poly1'); % trendline of field data
% x_f=0:1:120000;
% y_f1= -3.796e-06 * x_f + 1.581; 
% f2 = fit (distance,mouthbar,'poly1'); % trendline of field data
% y_f2 = 9.686e-06 * x_f + 1.718;
% % plot(x_f,y_f1,'color',[0.4 0.7 0.4])
% % plot(x_f,y_f2,'color',[1 0.5 0])

xlabel('distance from apex [m]')
ylabel ('thickness [m]')
xlim([0 12E+4])
ylim([0 4.5])

%% cross section
% fig2=figure
% set(fig2,'Position',[800,100,600,500])
% plot(xstrata,ystrata,'k');
% hold on
% plot(shoreline,etashoreline,'bo-');
% plot(fbb,etafbb,'rsq-');
% % pot(fbb,etafbb,'-v');
% % compaction: bottom of the topset deposit
% plot(r,eta-Dthick, '-');
% xlabel('distance [m]')
% ylabel('elevation [m]')