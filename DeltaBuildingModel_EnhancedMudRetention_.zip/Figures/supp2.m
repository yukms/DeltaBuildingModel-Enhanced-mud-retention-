clear
load mossy % t/Efolding time vs wetfraction
figure,plot(mossy(:,1),mossy(:,2),'k')
hold on

iii=0;
cc=linspace(0,1,11)/2;
for  Bc=1000:1000:10000
    iii=1+iii;
load(['[new]_Bc_' num2str(Bc) '_FracDeposit_' num2str(0) '.mat'])   
% clear shoreline
clear find
Achannel = shoreline * Bc ;
Atotal= (70*pi/180) * 0.5 * shoreline.^2;
wetfrac= Achannel./Atotal;

% e-folding time 계산
initial_value = wetfrac(1); % 초기값
efolding_value = initial_value / exp(1); % 초기값의 e 배
efolding_time_index = find(wetfrac <= efolding_value,1); % 초기값의 e 배가 되는 시간의 인덱스

efolding_time =(timeplot+100)./ (timeplot(efolding_time_index)+100);
plot(efolding_time,wetfrac,'color',[cc(iii),cc(iii),cc(iii)])
end
%
xlabel('time/efolding time [yr]');
ylabel('wet fraction')
xlim([0 6])
ylim([0 1])