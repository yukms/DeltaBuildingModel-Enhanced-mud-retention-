%         logic = r>thres;
%         Mud(1:M) = (2 * 35*pi/180 * (r(1:M)  - Bsand/2/cos(55*pi/180) ));
%         Sand(1:M) = r(1:M)' * 70*pi/180 - Mud(1:M);
%         lambig(1:M) = 1 + logic (1:M)'.*Mud(1:M)./Sand(1:M);


% %% r에 대한 lambig이 어떻게 되는지
% logic = r>thres;
%         Mud(1:M+1) = (2 * 35*pi/180 * (r(1:M+1)  - Bsand/2/cos(55*pi/180) ));
%         Sand(1:M+1) = r(1:M+1)' * 70*pi/180 - Mud(1:M+1);
%         lambig(1:M+1) = 1 + logic (1:M+1)'.*Mud(1:M+1)./Sand(1:M+1);
%         figure(1),plot(r,lambig)

% 
iii=0;
cc=linspace(0,1,20)/2;
subplot(1,2,1)
hold on
for Bc=1000:500:10000
    Bsand=Bc*5;
        iii=1+iii;

    thres = (Bsand)/2/cos(55*pi/180);      
s=[100: 100 : 110000 ];
logic= s>thres;
Mud = 2 * 35*pi/180 * (s  - Bsand/2/cos(55*pi/180)) ;
Sand = s * 70*pi/180 - Mud;
        lambig = 1 + logic .* Mud./Sand;
        lambig=lambig';        
        colormap gray
plot(s,lambig+1,'color',[cc(iii),cc(iii),cc(iii)])
end
xlabel('Distance [m]', 'FontName', 'Arial', 'FontSize', 12);
ylabel('Lambda node', 'FontName', 'Arial', 'FontSize', 12);
set(gca, 'FontName', 'Arial', 'FontSize', 14);
title('(c) lambda at node', 'FontName', 'Arial', 'FontSize', 14);

% colorbar




% %% 각 timestep 에서 전체 면적의 S/M 비율 : 최종 run 이후에 실행
% Atotal= (70*pi/180) * 0.5 * shoreline.^2;
% Amud=(35*pi/180) * (shoreline-thres).^2 ; % mud
% Asand=Atotal-Amud;
% ms_ratio=Amud./Asand+1;
% ms_ratio(shoreline<thres)=0;
% hold off
% figure(2),plot(timeplot+100,ms_ratio+1) % 하나의 레이어가 쌓일 동안의 m/s raio이 니까 x축에 time이 오는게 맞다.
% ylabel('lambda')
% xlabel('time yr')


iii=0;
cc=linspace(0,1,20)/2;
subplot(1,2,2)
hold on
for  Bc=1000:500:10000
    iii=1+iii;
load(['[new]_Bc_' num2str(Bc) '_FracDeposit_' num2str(0) '.mat'])   
clear shoreline
    Bsand=Bc*5;
    thres = (Bsand)/2/cos(55*pi/180);      
shoreline=[100:100:110000]';
Atotal= (70*pi/180) * 0.5 * shoreline.^2;
Amud=(35*pi/180) * (shoreline-thres).^2 ; % mud
Asand=Atotal-Amud;
ms_ratio=Amud./Asand+1;
ms_ratio(shoreline<thres)=0;

colormap gray
plot(shoreline,ms_ratio+1,'color',[cc(iii),cc(iii),cc(iii)])
end
% colorbar
xlabel('Distance [m]', 'FontName', 'Arial', 'FontSize', 12);
ylabel('Lambda surface', 'FontName', 'Arial', 'FontSize', 12);
set(gca, 'FontName', 'Arial', 'FontSize', 14);
title('그래프 제목', 'FontName', 'Arial', 'FontSize', 12);
title('(d) lambda surface', 'FontName', 'Arial', 'FontSize', 14);


