% figure chamberlain suggested

figure
hold on
load('[new]_Bc_50000_FracDeposit_0.mat')
plot(timeplot+100,shoreline,'r')
% load('[new]_Bc_50000_FracDeposit_600.mat')
% plot(timeplot+100,shoreline,'r--')


load('[new]_Bc_10000_FracDeposit_0.mat')
plot(timeplot+100,shoreline,'k')
load('[new]_Bc_10000_FracDeposit_600.mat')
plot(timeplot+100,shoreline,'k--')


load('[new]_Bc_1000_FracDeposit_0.mat')
plot(timeplot+100,shoreline,'c')
load('[new]_Bc_1000_FracDeposit_600.mat')
plot(timeplot+100,shoreline,'c--')


legend('Base model','Low retention Low bottomset','Low retention High bottomset'...
,'High retention Low bottomset','High retention High bottomset')
error=[150, 150, 110, 50, 80, 50, 70, 50, 60, 60];
year=[110, 140, 130, 540, 350, 500, 680, 660, 680, 860];
distance=[9000, 20000, 26000, 48000, 51000, 51000, 72000, 75000, 77000, 110000];
 errorbar( year,distance,error,'horizontal' ,'k+','linewidth',1);
xlabel('year')
ylabel('distance from apex [m]')
xlim([-100 1000])
ylim([0 12E4])