
load('[new]_Bc_1000_FracDeposit_0.mat')
zz=4:0.025:4.5;
figure
hold on
for tt = 1 : 50: 801
    
plot(xi, ynstrata(:,tt), 'k');

end
plot(r,eta-Dthick, 'c-');
plot(r,eta-Dthick-zz','r-','linewidth',0.8);
xlabel('distance [m]')
ylabel('elevation [m]')
% plot(shoreline,etashoreline,'-bo');
% 
% ((ystrata(1,801)-ystrata(31,801))/(xstrata(31,801)))
% shoreline(801,1)
% test