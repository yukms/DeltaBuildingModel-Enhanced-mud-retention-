%% input parameters
% twoD_Delta_InputParameters;
%% initial bed

ro = 0;
rs = rsI;
ru = rs + (etarsI-etaruI) / Sf;
% for i = 1 : M
%     rhat(i) = drhat * i;
%     r(i) = ro + (rs - ro) * rhat(i);
%     eta(i) = (rs - ro) * StI - (rs- ro) *StI *rhat(i) + etarsI;
%     rt(i)=r(i);
%     etat(i)=eta(i);
% end
rhat(1:M)=drhat.*(1:M);
r(1:M)=ro+(rs-ro).*rhat(1:M);
eta(1:M) = (rs - ro) * StI - (rs- ro) *StI *rhat(1:M) + etarsI;
rt(1:M)=r(1:M);
etat(1:M)=eta(1:M);

for i = 1:N
    jj=M+i;
    rmhat(i)=drmhat*(i-1);
    rm(i)=ru+(Lbasin-ru)*rmhat(i);
    etam(i)= etaruI-Sb*(rm(i)-ruI);
    rt(jj)=rm(i);
    etat(jj)=etam(i);
end




etaro = (rs-ro) *StI + etarsI;
etaroold = etaro;
etars = etarsI;
etaru = etaruI;
eta(M+1)=etaru;
etat(M+1)=eta(M+1);
r(M+1)=ru;
rt(M+1)=r(M+1);
time = 0;
etabro = eta(M+1) + Sb * (ru-ro);

% for guide channel
% for i =1 : N+1
%     x(i) = dx*(i-1);
%     etac(i)= Lc *StcI - x(i) *StcI + etaro;
%     rc(i) = x(i)-Lc;
% end

%         Volfin =0;
%         Finished = False;

% save stratigraphic data
ystrata(:,1)=[etaro;etat(:,1)];
xstrata(:,1)=[ro;rt(:,1)];
shoreline(1)=rsI;
fbb(1)=r(M+1);
etashoreline(1)=etarsI;
etafbb(1)=etaruI;
timeplot(1,1)=time; % 0

% compaction: stratal migration
% tempxstrata = [xstrata(:,1); Lbasin];
tempxstrata = [xstrata(:,1)];
% tempystrata = [ystrata(:,1); etab_Lbasin];
tempystrata = [ystrata(:,1)];

ynstrata(:,1) = interp1(tempxstrata, tempystrata, xi);

tempMObound = eta-Dthick; 
MObound = [tempMObound(1);tempMObound; etab_Lbasin];
MOboundary(:,1) = interp1(tempxstrata(1:M+3), MObound, xi);
%xnstrata(:,1) = xi;
%mstrata = ystrata(:,1);


% main
for j=1:1:Mprint
%     lambig=lambig_set(j);
    for w=1:1:Mtoprint
%% Find load

        % guide channel
%         Sc(1)= ( 1 / loadcoef ) * Qtc(1) / Qbfw;
%         Sc(2)= ( etac(2) - etac(3) ) /dx;
%         Sc(N+1) = (etac(N)-etac(N+1))/dx;
%         for i= 3 : N
%             Sc(i) = (etac(i-1)-etac(i+1))/(2*dx);
%         end
%         for i = 2 : N+1
%             Qtc(i)=loadcoef *Qbfw *Sc(i);
%         end
        
        % fan delta, normal flow
        %S(1) = ( 1 / loadcoef ) * Qbfs / Qbfw;
        S(1)=(eta(1)-eta(2)) / drhat / (rs-ro);
        S(M) = (eta(M-1) - eta(M) ) / drhat / (rs - ro);
        S(2:M-1)= (eta(1:M-2) - eta(3:M)) /2 / drhat / (rs-ro);
        Qt(1:M)=loadcoef*Qbfw*S(1:M);
        
        logic = r>thres;
        Mud(1:M) = (2 * 35*pi/180 * (r(1:M)  - Bsand/2/cos(55*pi/180) ));
        Sand(1:M) = r(1:M)' * 70*pi/180 - Mud(1:M);
        lambig(1:M) = 1 + logic (1:M)'.*Mud(1:M)./Sand(1:M);
        

        eta(M)=etars; % shoreline elevation = base level
%         etabro = eta(M+1) + Sb*(ru-ro);
        rsdot(j,1) = -1 / Sf * ((zeta + sigma)) + 1 / Sf * (Intf * (1 + lambig(M)) * Qt(M) / (1 - lamp) / (Captheta * (rs - ro + (eta(M) - etabro) / Sf) ^ 2 - (thetaF / 2) * (rs - ro) ^ 2));
        rudot(j,1) = 1 / (Sf - Sb) * (Sf * rsdot(j,1)) + 1 / (Sf - Sb) * (zeta + sigma);
%         Volfin = Volfin + dt * Qt(M) * Intf * (1 + lambig) / (1 - lamp);
%% Find new eta

        % guide channel
%         time = time + dt;
%         etac(1)=etac(2)+Sc(1)*dx;
%         for i = 2 : N
%             detac1 = Intf * (1 + lambig) * (Qtc(i - 1) - Qtc(i + 1)) / (2 * dx) / Bc / (1 - lamp);
%             detac2 = -sigma;
%             etac(i) = etac(i) + dt * (detac1 + detac2); %- sigma * dt + Intf * (1 + lambig) * (Qtc(i - 1) - Qtc(i + 1)) / (2 * dx) / Bc / (1 - lamp) * dt
% %             Volfin = Volfin + dt * (detac1) * dx * Bc
%         end
        
        % fan delta
        etatopold = eta(M);
        
        for i =1 : M-1
            if i == 1 
                Qtdev(i) = (Qt(i + 1) - Qbfs) / 2 / drhat; %(Qt(i + 1) - Qbfs) / 2 / drhat '
                etadev(i) = (eta(i + 1) - eta(i)) / drhat;
                Bsubdev(i) = (Bsub(i+1)-Bsub(i)) / drhat; % compaction
            else
                Qtdev(i) = (Qt(i + 1) - Qt(i - 1)) / 2 / drhat;
                etadev(i) = (eta(i + 1) - eta(i - 1)) / 2 / drhat;
                Bsubdev(i) = (Bsub(i+1)-Bsub(i-1)) /2/ drhat; % compaction       
            end 
        end
        
  
        
        etabase(1:M-1)=etabro-Sb*r(1:M-1);
        
        
        for i =1 : M-1
            deta1 = (-Intf * (1 + lambig(i)) * Qtdev(i) / (rs - ro) / (1 - lamp) / rhat(i) / (rs - ro) / thetaF);
            deta2 = etadev(i) / (rs - ro) * rhat(i) * rsdot(j,1);
            % compaction
            Dthick(i) = eta(i) - Bsub(i); % topset thickness
            Tthick(i) = eta(i) - etabase(i); % total thickness + Bay-Mud layer thickness
            Bthick(i) = Tthick(i) - Dthick(i); % baymud thickness + Foreset thickness
            % ro location: apex
            Dthickro = etaro - Bsub(1); % topset thickness
            Tthickro = etaro - etabro; % total thickness
            Bthickro = Tthickro - Dthickro; % baymud thickness
            
            deta3 = -sigma; %+ (rhat(i) * rsdot * Sb)
            % deta4 = -ktau*(Bthick(i)^3)*(Dthick(i)-(Tthick(i)-eta(i)-Bthick(i)))/timeyr;
            deta4 = -ktau*((BMthick_Init(i)+Bsub(i))^3)*(eta(i))/timeyr;
            %the compaction equation has an unit of m/yr, so divided by timeyr to match the unit here
            Bsub(i) = Bsub(i) + dt * (deta4 + Bsubdev(i) / (rs - ro) * rhat(i) * rsdot(j,1));
            % RIGHT HERE
            if i ==1
                deta4ro = -ktau*(Bthickro^3)*(Dthickro-(Tthickro-etaro-Bthickro))/timeyr;
                Bsubro = Bsub(i) + dt * (deta4 + Bsubdev(i) / (rs - ro) * rhat(i) * rsdot(j,1));
            end
                        
            eta(i) = eta(i) + dt * deta1;
            eta(i) = eta(i) + dt * deta2;
            eta(i) = eta(i) + dt * deta3;
            eta(i) = eta(i) + dt * deta4;
%             Volfin = Volfin + dt * (deta1 + deta2) * (rhat(i) * (rs - ro) * thetaF) * (drhat * (rs - ro));
        end
        
        rs= rs + rsdot(j,1) * dt;
        ru= ru + rudot(j,1) * dt;
        etaroold = etaro;
        etaro = eta(1) + (rs - ro) * drhat * S(1);
        etars = eta(M) + zeta * dt;
        

%         Volfin = Volfin + dt * (zeta + sigma) * (rhat(M) * (rs - ro) * thetaF) * (drhat * (rs - ro))
    
       

%% Find  load: advection settling reach


% % for i = 1:1:N
% %     jj=M+1+i;
% %      
% % 
% %      if i==1
% %      cibar(i) = cibar(i)- cibar(i)/H(i)*(-detam(i))*dt+(((qmo-qm(i))/dx)-(vsm)*(cibar(i)))*dt/H(i);  %sediment concentration at first node using the ghost node
% %      else
% %      cibar(i,k) = cibar(i)- cibar(i)/H(i)*(-detam(i))*dt+(((qm(i-1)-qm(i))/dx)-(vsm*(cibar(i))))*dt/H(i); %sediment concentration at other nodes
% %      end %for if
% %      qm(i) = cibar(i)*U(i)*H(i); %sediment discharge at each node
% % 
% % end
        for i = 1:1: N

                if i == 1
                    cibardev(i)=(cibar(i+1)-cibar(i))/drmhat;
                elseif i==N
                    cibardev(i)=(cibar(i)-cibar(i-1))/drmhat;
                else
                    cibardev(i)=(cibar(i+1)-cibar(i-1))/drmhat/2;
                end
            
        end
        
        for i = 1 : 1 : N
                            %% cibar volume ratio                                                  
            if i == 1 
                
                    cibar(i) = cibar(i) +  (rudot(j,1)*(1-rmhat(i))*cibardev(i)/(Lbasin-ru))*dt+...
                                            dt/H(i)*(-vsm*ro*cibar(i)-(cibar(i)*U(i)*H(i)-qmo)/((Lbasin-ru)*drmhat));
                 
            else
                   cibar(i) = cibar(i) +  (rudot(j,1)*(1-rmhat(i))*cibardev(i)/(Lbasin-ru))*dt+...
                                            dt/H(i)*(-vsm*ro*cibar(i)-(cibar(i)-cibar(i-1))*U(i)*H(i)/((Lbasin-ru)*drmhat));            
            end
        end
                    qm(1:N) = cibar(1:N).*U(1:N).*H(1:N); %sediment discharge at each node

%% 
%% Find new eta: advection settling reach

etaruold=etaru;

for i = 1:1:N
       if i == N
                etamdev(i) = (etam(i - 2) - etam(i)) / drmhat/2;
%                 Bsubdev(i) = (Bsub(i+1)-Bsub(i)) / drhat; % compaction
%        elseif i==N
%            etamdev(i)= (etam(i)-etam(i-1))/2/drmhat;
       else
                etamdev(i) = (etam(i+1 ) - etam(i))  / drmhat;
%                 Bsubdev(i) = (Bsub(i+1)-Bsub(i-1)) /2/ drhat; % compaction       
       end 
end
for i =1:1:N
    detam(i)=(near*vsm*qm(i)*Bc_bts/U(i)/H(i)/(1-lamp)/thetaF/(rm(i)) + rudot(j,1)*(1-rmhat(i))/(Lbasin-ru)*etamdev(i) )*dt;
    etam(i)=etam(i)+detam(i);
end
% vectorize but sloe
% tic
%     detam(1:N)=(near*vsm.*qm(1:N)*Bc_bts./U(1:N)./H(1:N)/(1-lamp)/thetaF./(rm(1:N)) + (rudot(j,1)*(1-rmhat(1:N))/(Lbasin-ru).*etamdev(1:N))' )*dt;
%     etam(1:N)=etam(1:N)+detam(1:N);
% toc
% 

        H=H-detam;
        U=qw./H;


        etaru = etam(1);
        eta(M + 1) = etaru;
        etat(M+1)=eta(M+1);
        r(M + 1) = ru;
        rt(M+1)=r(M+1);
        ro = ro + rodot * dt;
        
        for i = 1 : M
            r(i) = ro + (rs - ro) * rhat(i); 
            rt(i)=r(i);
            etat(i)=eta(i);
        end
   
            
        for i = 1:N
            jj=M+i;
            rm(i)=ru+(Lbasin-ru)*rmhat(i);
            rt(jj)=rm(i);
            etat(jj)=etam(i);
        end
        etabro = eta(M + 1) + Sb * (ru - ro); %added
        %etac(N + 1) = etaro;
        

    end % Ntoprint : w
        time=j*Mtoprint*dt;
        % save stratigraphic data
        ystrata(:,j+1)=[etaro;etat(:,1)];
        xstrata(:,j+1)=[ro;rt(:,1)];
        shoreline(j+1,1)=rs;
        etashoreline(j+1)=etars;
        fbb(j+1,1)=ru;
        etafbb(j+1)=etaru;
        timeplot(j+1,1)=time/timeyr;
        
        % compaction: stratal migration
        tempxstrata = [xstrata(:,j+1)];
        tempystrata = [ystrata(:,j+1)];
        
        ynstrata(:,j+1) = interp1(tempxstrata, tempystrata, xi);
        tempMObound = eta-Dthick; 
        MObound = [tempMObound(1);tempMObound; etab_Lbasin];
        MOboundary(:,j+1) = interp1(tempxstrata(1:M+3), MObound, xi);
        %xnstrata(:,j+1) = xi;
        
        % stratal migration routine:
%         for k=1:j
%             deltacomp = MOboundary(:,k)-MOboundary(:,k+1);
%             deltacomp(deltacomp<0)=0;
%             ynstrata(:,k)= ynstrata(:,k)-deltacomp;
%         end
    
end % Nprint : j

for k=1:j
    deltacomp = MOboundary(:,k)-MOboundary(:,j+1);
    %deltacomp(deltacomp<0)=0;
    sn = round(shoreline(k)/dxC);
    deltacomp([sn+1:length(deltacomp)],1) = deltacomp(sn);
    ynstrata(:,k)= ynstrata(:,k)-deltacomp;
end
        
% figure,plot(xstrata,ystrata,'k');
% hold on
% plot(shoreline,etashoreline,'bo-');
% plot(fbb,etafbb,'rsq-');
% % pot(fbb,etafbb,'-v');
% % compaction: bottom of the topset deposit
% plot(r,eta-Dthick, '-');
% xlabel('distance [m]')
% ylabel('elevation [m]')
% 
% zz=4:0.025:4.5;
% figure, plot(xi, ynstrata, 'k');
% hold on
% plot(r,eta-Dthick, 'c-');
% plot(r,eta-Dthick-zz','r-','linewidth',3);
% xlabel('distance [m]')
% ylabel('elevation [m]')
% plot(shoreline,etashoreline,'-bo');
% 
% ((ystrata(1,801)-ystrata(31,801))/(xstrata(31,801)))
% shoreline(801,1)
% test