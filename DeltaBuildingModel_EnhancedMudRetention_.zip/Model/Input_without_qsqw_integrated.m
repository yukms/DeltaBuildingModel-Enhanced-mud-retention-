% Auxiliary Parameters 
% clear all; 

aleh=0.1;
neh=2.5;
tausforms=1.86;
alp=11.2;
np=4.5;
tausc=0.03;
tausformg=0.0487;
timeday=86400;  % timeday = 24*60*60; % seconds in a day
timeyr=31557600; %timeyr = 365.25*24*60*60; % seconds in a year

%% Get data
Bcmultiple=5; % Bc*5
Bsand=Bc*Bcmultiple;
thres = (Bsand)/2/cos(55*pi/180);      

FracSand = 0.183175; %D8 Fraction sand
Intf = 0.34; %D9 intermittency
Rr=1.65; % Submerged specific gravity of sediment
annualBedloadSand = FracSand*Qbfst; %D8*D7 Mt/yr
annualBedloadSand = annualBedloadSand/(Rr+1)*1000000/(60*60*24*365.25); %m3/s
FloodBedload = annualBedloadSand/Intf; % flood bed load
Ndiversion=1; % number of diversion
Fdiversion=1; % fraction of diversion
Qbfw = Qbf/Ndiversion*Fdiversion; % Flood discharge to one diversion [m3/s]
Qbfs = FloodBedload/Ndiversion*Fdiversion;
 
annualBedloadtoOnediversion=Qbfs*(Rr+1)*(60*60*24*365.25)*Intf/1000000;

% lambig = 1; % Units of wash load deposited in the fan per unit sand load deposited

% lambig_set = linspace(0.5,1.5,Mprint);

D = 0.1; % grain size of sand [mm]
Dm = 0.01; % grain size of mud [mm]
lamp = 0.6 ; % bed porosity
Cz = 20; % Chezy Resistance Coef
%Czs = 15; 

lamp_prodelta = 0.78; % prosity at prodelta
squeeze=0; % squisy layer thickness [m]
Hsq = squeeze*(1-(1-lamp_prodelta)/(1-lamp)); % squeezed thickness [m]
etarsI = 0; % elevation of top of the foreset
etaruI = -4; % initial elevation of bottom of the foreset
etarul = etaruI-Hsq;
rsI = 13932; % initial length of the fan [m]

StI = 1.5E-05; % initial slope of fluvial bed
% StI=4.0000e-05;
Sb = 0; %-4E-05; % subaqueous basement slope 
Sf = 0.005 ; % slope of foreset face
thetaF = 70 ; % deg
thetaF = thetaF / 360 * (2 * pi());
zeta = 0.5; % rate of base level rise [mm/yr]
zeta = zeta / 1000 / timeyr;
sigma = 0; % rate of subsidence  [mm/yr]
sigma = sigma / 1000 / timeyr;

% % guide channel input parameters

N = 20 ; %MS: Number of intervals in advection settling zone
M =  20; %Number of intervals in fan delta
dr = rsI / M; % spatial step of fan delta
dt = 0.000025*365.25; %time step ,  days
Mtoprint = 2E+06/5 ; % Number of time steps to print out
Mtoprint= Mtoprint/10;

dt=dt*2;
Mtoprint=Mtoprint/2;
Mprint = 20*4*10; % Number of printout
Lbasin = 200000;    % Total basin length [m]  120000
% parameters for compaction
ktau = 9e-16;    % compaction coefficient in year
tau = 9;    % decay constant in year
% ktau=0;
% tau=0;

ktau = ktau*timeyr;
tau = tau*timeyr;

Cf = 1 / Cz ^ 2;
rform =(1-tausc /tausformg)^4.5;
Draw = D;
        if Draw < 2   %mud 
            tausform = tausforms;
            loadcoef = aleh * tausform / (Rr) / (Cf ^ 0.5);
           % 'loadcoef = aleh * tausform / (Rr ^ (3 / 2)) / (Cf ^ 0.5)
            widthcoef = Cf / (aleh * tausform ^ 2.5 * Rr ^ 0.5);
            depthcoef = aleh * (tausform ^ 2) / (Cf ^ 0.5);
        else % sand
            tausform = tausformg;
            loadcoef = alp * rform * (Cf ^ 0.5) / Rr;
            widthcoef = 1 / (alp * (tausform ^ 1.5) * (Rr ^ 0.5) * rform);
            depthcoef = alp * tausform * rform * (Cf ^ 0.5);
        end
        
        D = D / 1000;
        drhat = 1 / M;
        %dx = Lc / N;
        %Qtc(1) = Qbfs;
        dt = timeday * dt; % in seconds
        phi = 2 / thetaF * sin(thetaF / 2);
        psi = Sb / Sf;

% spreading angle over the foreset different from the delta topset        
Captheta = 0;
        for c = 1 : 100
            dtheta = (thetaF / 2) * (1 / 100);
            theta = dtheta * c;
            Captheta = Captheta + dtheta * ((1 - psi * cos(theta)) ^ (-2));
        end
        
        % defining some parameters
        xstrata=zeros(M+N+1,Mprint+1);
        ystrata=zeros(M+N+1,Mprint+1);
        r=zeros(M+1,1);
        %rc=zeros(N+1,1);
        eta=zeros(M+1,1);

        %etac=zeros(N+1,1);
        shoreline=zeros(Mprint+1,1);
        etashoreline=zeros(Mprint+1,1);
        rsdot=zeros(Mprint+1,1);
        rudot=zeros(Mprint+1,1);
        rodot=0;
        timeplot=zeros(Mprint+1,1);
        
        % compaction
        Dthick = zeros(M+1,1); % topset thickness
        Tthick = zeros(M+1,1); % total thickness
        Bthick = zeros(M+1,1); % bay thickness (foreset)
        Bsub = zeros(M+1,1); % subsidence
        Bsubdev = zeros(M+1,1); % dev
        
        % compaction strata: Bay-Mud layer
        BMthick_Init = zeros(M+1,1); % bay-mud thickness beneath of the delta
        BMthick_Init(:,1) = 40; % Initial uniform thickness 
        
% Parameters for stratal migration
ruI = rsI + (etarsI-etaruI) / Sf;
etab_Lbasin = etaruI - Sb*(Lbasin-ruI);   % Elevation at the basin end
dxC = 200;
xnstrata = zeros(Lbasin/dxC+1, Mprint+1);
ynstrata = zeros(Lbasin/dxC+1, Mprint+1);
MOboundary = zeros(Lbasin/dxC+1, Mprint+1);
xi = (0:dxC:Lbasin);

tempxstrata = zeros(M+2+1);
tempystrata = zeros(M+2+1);

% Defining parameters for speed
rhat = zeros(M,1);
S = zeros(M,1);
etadev = zeros(M-1,1);
etabase = zeros(M-1,1); 
Qt = zeros(M,1);
qm = zeros(N,1);
S=zeros(M,1);
Qt=zeros(M,1);
rsdot=zeros(Mprint+1,1);
rudot=zeros(Mprint+1,1);
Qtdev=zeros(1,M-1);
etadev=zeros(M-1,1);
Bsubdev=zeros(M+1,1);
etabase=zeros(M-1,1);
Dthick=zeros(M+1,1);
Bthick=zeros(M+1,1);
Tthick=zeros(M+1,1);
Bsub=zeros(M+1,1);
cibardev=zeros(N,1);
cibar=zeros(N,1);
qm=zeros(N,1);
etamdev=zeros(1,N);
detam=zeros(N,1);
shoreline=zeros(Mprint+1,1);
etashoreline=zeros(Mprint+1,1);
fbb=zeros(Mprint+1,1);
etafbb=zeros(Mprint+1,1);




% Parameters for advection settling

        rm=zeros(N,1);
        etam=zeros(N,1);

        rt=zeros(M+N,1);
        etat=zeros(M+N,1);
        drmhat = 1 / N;
        cibar=zeros(N,1);
        cibardev=zeros(N,1);
%         Qmi = Qbfs / FracSand * (1-FracSand) * FracDeposit; % MS: Fracdeposit = Retention rate
        cibar=zeros(N,1);
        H=ones(N,1)*etaruI*(-1);
        Bc_bts=1000;
        qw=10000/Bc_bts;
        U=qw./H;
        detam=zeros(N,1);
%         qmo=Qmi/Bc_bts;
        
        Rm=1.65;
        nu = 1e-6;
        g = 9.81; 
        near= 1;
        
        Rep = ((Rm * g * Dm) ^ 0.5) * Dm / nu;
        xx = log(Rep ^ 2) / log(10);
        yy = -3.76715 + 1.92944 * xx - 0.09815 * (xx ^ 2) - 0.00575 * (xx ^ 3) + 0.00056 * (xx ^ 4);
        Rf = ((10 ^ yy) / Rep) ^ (1 / 3);
        vsm =  Rf * ((Rm * g * Dm) ^ 0.5);
