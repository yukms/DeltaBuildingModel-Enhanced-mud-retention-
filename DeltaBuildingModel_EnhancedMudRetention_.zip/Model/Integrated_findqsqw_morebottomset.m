%% small mesh 0.1 % relative error calibration
clear
clc

Bcc = 1000:100:10000;
pattern_to_remove = 1000:500:10000;
Bcc = setdiff(Bcc, pattern_to_remove);
Qbfst=20; % initial value before calibration
Qbf=1000; % initial value before calibration
for i=1:length(Bcc)
Bc=Bcc(i);

for qmo= 0.0E-08: 0.5E-08 : 0.0E-08


Input_without_qsqw_integrated
twoD_Delta_Run_integrated

step_size=1;



for find=1:300
% while abs((shoreline(801,1)-101532) /101532)<0.001 && abs((((ystrata(1,801)-ystrata(41,801))/(xstrata(41,801)))- (4E-05) )/ (4E-05))<0.001


   
    prev_relative_error=1;
while abs((shoreline(801,1)-101532) /101532)>0.001
            fprintf(' Qs finding \n')
    if shoreline(801,1) > 101532 
        Qbfst = Qbfst - step_size;
    elseif shoreline(801,1) < 101532
        Qbfst = Qbfst + step_size;
    end
    
    
    relative_error = abs((shoreline(801,1)-101532) /101532);
    if relative_error <= 0.001
        break;
    end
%     step_size %
%     relative_error>=prev_relative_error %
    if relative_error >= prev_relative_error
        step_size = step_size/2
    end
%     step_size 
    prev_relative_error=relative_error;
% tic    
       Input_without_qsqw_integrated
       twoD_Delta_Run_integrated
% toc
 fprintf('Qbf %g Qbfst %g  shoreline %g \n ',Qbf,Qbfst,shoreline(801,1))

end


fprintf(' Qs passed\n')
   

prev_relative_error_Qw=1;
while abs((((ystrata(1,801)-ystrata(41,801))/(xstrata(41,801)))- (4E-05) )/ (4E-05)) >0.001
                fprintf(' Qw finding \n')
                
    relative_error_Qw=  abs((((ystrata(1,801)-ystrata(41,801))/(xstrata(41,801)))- (4E-05) )/ (4E-05));
if relative_error_Qw >= 0.1
    step_size_Qw = 20;
elseif 0.005 <= relative_error_Qw && relative_error_Qw < 0.1
    step_size_Qw = 10;
elseif relative_error_Qw < 0.005
    step_size_Qw = 1;
end
  fprintf('E %g Step %g \n',relative_error_Qw,step_size_Qw)

           
                
    if ((ystrata(1,801)-ystrata(41,801))/(xstrata(41,801))) > 4E-05
        Qbf = Qbf + step_size_Qw;
    elseif ((ystrata(1,801)-ystrata(41,801))/(xstrata(41,801))) < 4E-05 
        Qbf = Qbf - step_size_Qw;
    end
    
    if relative_error_Qw <= 0.001
        break;
    end
  
     Input_without_qsqw_integrated
     twoD_Delta_Run_integrated
           fprintf('Qbf %g Qbfst %g  slope  %e \n',Qbf,Qbfst,((ystrata(1,801)-ystrata(41,801))/(xstrata(41,801))))

end

fprintf(' Qw passed\n')

end
test

 filename = sprintf('[new]_Bc_%g_FracDeposit_%g.mat', Bc,qmo*10E+9); 
  save(filename);
  fprintf('Bc %g FracDeposit %g is callibrated! \n\n\n\n',Bc,qmo *10E+9)
%   zz=4:0.025:4.5;
% figure, plot(xi, ynstrata, 'k');
% hold on
% plot(r,eta-Dthick, 'c-');
% plot(r,eta-Dthick-zz','r-','linewidth',3);
% xlabel('distance [m]')
% ylabel('elevation [m]')
% plot(shoreline,etashoreline,'-bo');

end %qmo for
end

